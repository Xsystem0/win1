using System.Diagnostics;
namespace WInew
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void endSessionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("you traying to endsesion me i'm not dump to let you try endsesion mi hahhaha", "endsesion");
        }

        private void informationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("win1 version 0", "information");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("you traying to close me i'm not dump to let you try close mi hahhaha", "exit");
        }

        private void deleteFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Error", "error");
        }

        private void Paint_Click(object sender, EventArgs e)
        {
            Process.Start("mspaint");
        }

        private void crashToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Error you pc ran into a ishue ERROR code 0", "waiting");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
